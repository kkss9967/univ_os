package os;

import java.util.Vector;

import processManager.Process;
import processManager.Process.EState;

public class ProcessQueue {

	private Vector<Process> queue;

	private int size;
	public int getSize() {return size;}
	
	public ProcessQueue() {
		this.queue = new Vector<Process>();
	}

	public void enqueue(Process process) {
		// ����ť
		this.queue.add(process);
		size++;
	}

	public Process dequeue(int PID) {
	      for(int i = queue.size()-1; i >= 0; i--) {
	         if(PID == queue.elementAt(i).getPcb().getId()) {
	            return queue.elementAt(i);
	         }
	      }
	      return null;
	   }

	public void deleteQ(int PID) {
		for (int i = queue.size() - 1; i >= 0; i--) {
			//System.out.println("~~~~~" + queue.elementAt(i).getPcb().getId());
			if (PID == queue.elementAt(i).getPcb().getId()) {
				queue.remove(i);
				size--;
			}
		}
	}

	public Process getProcess(int PID) {
		for (int i = 0; i < this.queue.size(); i++) {
			if (PID == this.queue.get(i).getPcb().getId()) {
				return this.queue.get(i);
			}
		}
		return null;
	}

	public void setState() {
		if(this.queue.size() > 0) {
		this.queue.elementAt(0).getPcb().seteState(EState.running);
		for(int i = 1; i < queue.size(); i++)
			this.queue.elementAt(i).getPcb().seteState(EState.ready);		
		}
	}

	public Process currentProcess() {
		if(queue.size() > 0) {
			return this.queue.elementAt(0);
		} else {
			return null;
		}
	}

}

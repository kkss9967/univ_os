package os;

import Device.Monitor;

public class Main {
	static Monitor monitor;
	public static class BIOS {
		
		public void run() {
			monitor = new Monitor();
		}
	}
	
	public static void main(String[] args) {
		BIOS bios = new BIOS();	
		bios.run();	
		
		OperatingSystem operatingSystem = new OperatingSystem();
		operatingSystem.initialize(monitor);
		operatingSystem.associate();
		operatingSystem.run();
		operatingSystem.finalize();
		
	}
}

// Dispatcher -> Context-Switching
// Interrupt -> IOStarted, IOFinished
// Multi-Processing -> File �� �� �̻� ������
package os;

import cpu.CentralProcessingUnit;
import cpu.Register;
import memory.Memory;
import processManager.InterruptHandler;
import processManager.Process;
import processManager.Process.ERegister;

public class MemoryManager {
	
	// allocate memory and set PCB info
	private Memory memory;
	private Register relocation;
	private Register limit;
	private int pageSize = 100;
	private int processID;
	
	public MemoryManager() {
		this.memory = new Memory();
		this.relocation = new Register();
		this.limit = new Register();
		this.processID = 0;
	}
	
	public void associate(CentralProcessingUnit CPU, InterruptHandler interruptHandler) {
		CPU.connect(memory);
		this.memory.associate(interruptHandler);
	}
	
	public void allocate(Process process) {
		process.getPcb().setId(processID);

		relocation.setData(processID * pageSize); // �����ּ�
		int temp = relocation.getData();
		for (int i = 0; i < process.getCodeSegment().getMemory().length; i++) {
			this.memory.getBuffer()[temp] = process.getCodeSegment().getMemory()[i];
			temp++;
		}

		process.getPcb().getRegisters().elementAt(ERegister.ePC.ordinal()).setData(0);
		process.getPcb().getRegisters().elementAt(ERegister.eCS.ordinal()).setData(relocation.getData());
		process.getPcb().getRegisters().elementAt(ERegister.eSP.ordinal()).setData(relocation.getData() + process.getCodeSegment().getMemory().length);

		this.processID++;
	}

}

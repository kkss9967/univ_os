package os;

import processManager.Loader;
import processManager.Process;
import processManager.ProcessManager;

public class UXManager {

	private FileManager fileManager;
	private ProcessManager processManager;
	private Loader loader;
	
	public UXManager() {
		
	}
	
	public void associate(FileManager fileManager, ProcessManager processManager, Loader loader) {
		this.fileManager = fileManager;	
		this.processManager = processManager;
		this.loader = loader;
	}
	public void run() {
//		Scanner sc = new Scanner(System.in);
//		String fileName =  sc.nextLine();	// ������ ������ console�� �Է��ϰ� �Ǿ��ִµ�...
		String fileName = "exe/p1.ppp";
		String fileName2 = "exe/p2.ppp";

		Process process = this.fileManager.getFile(fileName);	//������
		Process process2 = this.fileManager.getFile(fileName2);

		this.loader.load(process);
		this.loader.load(process2);
		
		this.processManager.dispatcher.enqueue(process);
		this.processManager.dispatcher.enqueue(process2);
		
		this.processManager.run();	

		
	}

}

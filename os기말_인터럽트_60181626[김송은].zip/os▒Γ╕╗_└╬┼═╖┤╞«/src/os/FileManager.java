package os;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;

import processManager.Process;

public class FileManager {

	public Process getFile(String fileName) {
		try {
			int stackSegmentSize = 0;
			int[] codes = null;

			File file = new File(fileName);
			Scanner sc = new Scanner(file);
			while (sc.hasNext()) {
				try {
					String line = sc.nextLine(); // �� ����, �ڸ�Ʈ ���� �� ��ŵ�ؾ���!

					if (line.substring(0, 2).equals("//")) {

					} else if (line.isEmpty()) { // isBlank�� �����̽��ٱ���. Empty�� ���͸� �Ÿ��ٰ� ��

					} else if (line.substring(0, 5).contentEquals(".code")) { // ���׸�Ʈ
						codes = this.parseCode(sc);
					} else if (line.substring(0, 6).contentEquals(".stack")) {
						stackSegmentSize = this.parseStack(sc);
					}

				} catch (StringIndexOutOfBoundsException e) {
					//
				}
			}
			Process process = new Process(stackSegmentSize, codes); // exe����
			sc.close();
			return process;

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		return null;
	}

	private int parseStack(Scanner sc) {
		int stackSize = 0;
		boolean check = true;
		while (check) {
			String stackLine = sc.nextLine();
			if (stackLine.substring(0, 2).equals("//")) {

			} else if (stackLine.substring(0, 4).equals("size")) {
				String[] sta = stackLine.split(" ");
				stackSize = Integer.parseInt(sta[2]);
				return stackSize;
			}
		}
		return stackSize;
	}

	private int[] parseCode(Scanner sc) {
		Vector<Integer> oww = new Vector<Integer>();
		int loopIndex = 0;
		while (sc.hasNext()) {
			try {
				String codeLine = sc.nextLine();
				if (!(codeLine.isEmpty())) { // isBlank�� �����̽��ٱ���. Empty�� ���͸� �Ÿ��ٰ� ��
					if (!(codeLine.substring(0, 2).equals("//"))) {
						String[] temp = codeLine.split(" ");
						int instruction = 0;
						if (temp[0].equals("ldv")) {
							instruction = (0 << 16) + Integer.parseInt(temp[1]);
							// System.out.println(codeLine);
						} else if (temp[0].equals("lda")) {
							instruction = (1 << 16) + Integer.parseInt(temp[1]);
						} else if (temp[0].equals("adv")) {
							instruction = (2 << 16) + Integer.parseInt(temp[1]);
						} else if (temp[0].equals("ada")) {
							instruction = (3 << 16) + Integer.parseInt(temp[1]);
						} else if (temp[0].equals("sta")) {
							instruction = (4 << 16) + Integer.parseInt(temp[1]);
						} else if (temp[0].equals("jgz")) {
							instruction = (5 << 16);
						} else if (temp[0].equals("cmp")) {
							instruction = (6 << 16) + Integer.parseInt(temp[1]);
						} else if (temp[0].equals("halt")) {
							instruction = (7 << 16);
						} else if (temp[0].equals("int")) {
							instruction = (8 << 16) + Integer.parseInt(temp[1]);
						} else if (temp[0].equals("loop:")) {
							instruction = (9 << 16) + loopIndex;
						}
						oww.add(instruction);
						loopIndex++;
					}
				}
			} catch (StringIndexOutOfBoundsException e) {
			}
		}
		int[] ow = new int[oww.size()];
		for (int i = 0; i < oww.size(); i++) {
			ow[i] = oww.elementAt(i);
		}
		return ow;
	}

}

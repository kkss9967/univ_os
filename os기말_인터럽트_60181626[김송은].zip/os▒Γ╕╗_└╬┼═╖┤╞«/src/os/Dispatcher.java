// ������ �Ƹ��� �ϼ�

package os;

import cpu.CentralProcessingUnit;
import cpu.Register;
import cpu.Status;
import processManager.InterruptHandler.EInterrupt;
import processManager.Process.ERegister;
import processManager.Process;

public class Dispatcher {

	private ProcessQueue readyQueue;
	private ProcessQueue ioQueue;

	private Process currentProcess;
	private CentralProcessingUnit CPU;

	public void associate(CentralProcessingUnit CPU) {
		this.CPU = CPU;

	}

	public Dispatcher() {
		this.ioQueue = new ProcessQueue();
		this.readyQueue = new ProcessQueue();
	}

	public void enqueue(Process process) {
		this.readyQueue.enqueue(process);
	}

	public Process dequeue(int PID) {
		if (readyQueue.dequeue(PID) == null) {
			return ioQueue.dequeue(PID);
		} else {
			return readyQueue.dequeue(PID);
		}
	}

	public void deleteQ(int PID) {
		this.readyQueue.deleteQ(PID);
		this.ioQueue.deleteQ(PID);
	}

	public void contextSwitching(EInterrupt eInterrupt, int PID) {

		this.currentProcess = this.dequeue(PID);

		if (!eInterrupt.equals(EInterrupt.eIOFinished)) {
			this.setProcess();
		}

		if (eInterrupt.equals(EInterrupt.eProcessTerminated)) {
			this.deleteQ(PID);

		} else if (eInterrupt.equals(EInterrupt.eTimeFinished)) {
			this.deleteQ(PID);
			this.enqueue(this.currentProcess);

		} else if (eInterrupt.equals(EInterrupt.eIOStarted)) {
			System.out.println(this.currentProcess.getPcb().getId() + "_PID --------> ���ؽ�Ʈ ����Ī");
			this.deleteQ(PID);
			this.ioQueue.enqueue(this.currentProcess);

		} else if (eInterrupt.equals(EInterrupt.eIOFinished)) {
			Process newProcess = this.dequeue(PID);
			this.deleteQ(PID);
			// IOť���� ���μ��� ����
			this.enqueue(newProcess); /// ������!!!!!!!!!!!!
			// System.out.println(this.currentProcess.getPcb().getId() + " PID "
			// +
			// this.currentProcess.getPcb().getRegisters().get(Process.ERegister.ePC.ordinal()).getData()
			// + " PC "
			// +
			// this.currentProcess.getPcb().getRegisters().get(Process.ERegister.eCS.ordinal()).getData()
			// + " CS ");
			// System.out.println();
		}

		this.readyQueue.setState();

		if (this.readyQueue.getSize() > 0) {
			// eIO�ǴϽ� �� �� PCB ����Ī�� �ϸ� �ȵ�.
			this.setCPU(this.currentProcess());
		}
	}

	public void setCPU(Process process) {
		this.CPU.setPCB(process.getPcb().getRegisters().get(Process.ERegister.ePC.ordinal()),
				process.getPcb().getRegisters().get(Process.ERegister.eCS.ordinal()),
				process.getPcb().getRegisters().get(Process.ERegister.eSP.ordinal()),
				process.getPcb().getRegisters().get(Process.ERegister.eAC.ordinal()), process.getPcb().getStatus());
	}

	public void setProcess() {
//		 System.out.println(this.CPU.getPC().getData() + "CPU PC");
		this.currentProcess.getPcb().getRegisters().get(Process.ERegister.ePC.ordinal()).setData(CPU.getPC().getData());
		this.currentProcess.getPcb().getRegisters().get(Process.ERegister.eAC.ordinal()).setData(CPU.getAC().getData());
		this.currentProcess.getPcb().setStatus(CPU.getStatus());
	}

	public Process currentProcess() {
		return this.readyQueue.currentProcess();
	}

	public boolean getCheck() {
		if (this.readyQueue.getSize() > 0) {
			return true;
		} else {
			return false;
		}
	}

}
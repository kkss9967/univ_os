package os;

import Device.Monitor;
import processManager.Loader;
import processManager.ProcessManager;

public class OperatingSystem {

	private UXManager uxManager;	//UI
	
	private ProcessManager processManager;
	private MemoryManager memoryManager;
	private FileManager fileManager;
	
	private Monitor monitor;
	// I/O�Ŵ��� ����
	private Loader loader;
	
	public OperatingSystem() {
		this.processManager= new ProcessManager();	//CPU
		this.memoryManager = new MemoryManager();	
		this.fileManager = new FileManager();	//HD
		
		this.uxManager = new UXManager();
		
		this.loader = new Loader();
		
		// �α���, ���� context
	}
	
	public void initialize(Monitor monitor) {
		// IO����̽� �ε�
		// ��� IO����̽��� ��Ʈ�ѷ����� get information.
		this.monitor = monitor;
	}
	
	public void finalize() {
		// TODO Auto-generated method stub
		
	}
	
	public void associate() {
		this.processManager.associate(this.memoryManager, this.monitor);
		this.uxManager.associate(this.fileManager, this.processManager, this.loader);
		this.loader.associate(this.memoryManager);
	
	}
	
	public void run() {
		uxManager.run();

	}

}

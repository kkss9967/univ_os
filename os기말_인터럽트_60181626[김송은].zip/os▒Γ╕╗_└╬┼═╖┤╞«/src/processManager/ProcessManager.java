package processManager;

import Device.IOController;
import Device.Monitor;
import cpu.CentralProcessingUnit;
import os.Dispatcher;
import os.MemoryManager;

public class ProcessManager {

	// components
	private InterruptHandler interruptHandler;
	public Dispatcher dispatcher;

	private CentralProcessingUnit CPU;
	private Process CurrentProcess;
	private IOController ioController;

	// association
	private MemoryManager memoryManager;

	// constructor ������
	public ProcessManager() {
		this.dispatcher = new Dispatcher();

		this.CPU = new CentralProcessingUnit();
		this.interruptHandler = new InterruptHandler();
		this.ioController = new IOController();
	}

	public void associate(MemoryManager memoryManager, Monitor monitor) {
		this.memoryManager = memoryManager;
		this.dispatcher.associate(CPU);
		this.interruptHandler.associate(monitor, dispatcher, ioController);
		this.memoryManager.associate(CPU, interruptHandler);
	}

	// public static int TIMESLICE = 10; // �и�������(1/1000��)

	public void execute() {
		// �ڵ� �� �� ����
		if(this.dispatcher.getCheck())
			this.CPU.run();
	}

	public void run() {
		CurrentProcess = this.dispatcher.currentProcess();
		this.dispatcher.setCPU(CurrentProcess);
		this.interruptHandler.resetTimer();
		while (true) {	
			this.interruptHandler.checkTimer();
			this.execute(); // ���μ��� ���� ����
			this.interruptHandler.checkFinish();	
			this.interruptHandler.process(); // ���ͷ�Ʈ �÷��� ����
		}
	}

}

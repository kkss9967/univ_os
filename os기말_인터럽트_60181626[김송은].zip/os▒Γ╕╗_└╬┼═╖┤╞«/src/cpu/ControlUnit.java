package cpu;

import memory.Memory;
import processManager.InterruptHandler.EInterrupt;

public class ControlUnit {
//	enum EState {halt, running};

	public enum EInstruction {LDV, LDA, ADV, ADA, STA, JGZ, CMP, HLT, INT, LOOP};

	// associations
	private Register pc, sp, cs, mar, mbr, ir, ac;
	private ArithmeticLogicUnit arithmeticLogicUnit;
	private Memory memory;
	private Status status;
	
	public Register getPc() {return pc;}
	public void setPc(Register pc) {this.pc = pc;}
	public Register getSp() {return sp;}
	public void setSp(Register sp) {this.sp = sp;}
	public Register getCs() {return cs;}
	public void setCs(Register cs) {this.cs = cs;}
	public Register getMar() {return mar;}
	public void setMar(Register mar) {this.mar = mar;}
	public Register getMbr() {return mbr;}
	public void setMbr(Register mbr) {this.mbr = mbr;}
	public Register getIr() {return ir;}
	public void setIr(Register ir) {this.ir = ir;}
	public Register getAc() {return ac;}
	public void setAc(Register ac) {this.ac = ac;}
	public Status getStatus() {return this.status;}
	public void setStatus(Status status) {this.status = status;}
	
	public ArithmeticLogicUnit getArithmeticLogicUnit() {
		return arithmeticLogicUnit;
	}
	public void setArithmeticLogicUnit(ArithmeticLogicUnit arithmeticLogicUnit) {
		this.arithmeticLogicUnit = arithmeticLogicUnit;
	}

	public ControlUnit() {
			
	}
	
	public void connect(Register pc, Register mar, Register mbr, Register ir, Register sp, Register cs, Register ac, Status status) {
		this.pc = pc;
		this.mar = mar;
		this.mbr = mbr;
		this.ir = ir;
		this.sp = sp;
		this.cs = cs;
		this.ac = ac;
		this.status = status;
	}

	public void connect(ArithmeticLogicUnit arithmeticLogicUnit) {
		this.arithmeticLogicUnit = arithmeticLogicUnit;
	}

	public void connect(Memory memory) {
		this.memory = memory;
	}

	public void run() {
		System.out.println("@@@ pc : " + this.pc.getData() + " / sp : " + this.sp.getData() + " / ac " + this.ac.getData());
		this.fetch();
		this.decode();
		this.status.interruptCheck();
		// true �߸� print ���ͷ�Ʈ (IO��ŸƮ) ������ ��.
		if(this.status.interruptCheck()) {
//			this.mbr.setData(this.ac.getData());
			this.memory.addInterrupt(this.ac.getData(), (this.cs.getData()/100));
			// result, pid
			this.status.deleteInterrupt();
		}
		if(this.status.haltCheck()) {
			this.memory.addHalt((this.cs.getData()/100));
			this.status.deleteHalt();
		}
	}
	
	private void fetch() {
		this.mar.setData(this.pc.getData() + this.cs.getData()); // pc�� �ּҸ� mar�� �ű�	// cs �����ּ�
		this.memory.fetch(); // mbr�� �����ִٰ� ���� //null ����! �޸�.fetch �� �� �������͵��� null
		this.ir.setData(this.mbr.getData());
	}

	private void decode() {
		
//      for(int i = 0; i < 300; i++) {}
//      if(this.pc.getData() == 8)
//      System.out.println(this.memory.getBuffer()[27] + "�ƾƾƾƤ��ƾƾƾƾƤ��ƾƾƤ��ƾӾƤ��ƾƾƤ��ƾ�");
//      System.out.println("pc : " +this.pc.getData()
//                     + " sp : " + this.sp.getData()
//                     + " cs : " + this.cs.getData()
//                     + " ac : " + this.ac.getData()
//                     );
		
//		for(int i=0; i < 100; i++) { } // delay
		// System.out.println(EInstruction.values()[(this.memory.getBuffer()[107] >>> 16)] + " " + (this.memory.getBuffer()[107] & 0x0000ffff) + "#!@#!");
		int instruction = this.ir.getData() >>> 16;
//		System.out.println(this.pc.getData());
//		int dataOrAddress = this.ir.getData() & 0x0000FFFF;
//		System.out.print("pc : " + this.pc.getData() + " / sp : " + this.sp.getData() + " / ac " + this.ac.getData() + " // " + EInstruction.values()[instruction] + " ");
//		System.out.println(dataOrAddress);
		switch(EInstruction.values()[instruction]) {
			case LDV:
				LDV();
				break;
			case LDA:
				LDA();
				break;
			case ADV:
				ADV();
				break;
			case ADA:
				ADA();
				break;
			case STA:
				STA();
				break;
			case JGZ:
				JGZ();
				break;
			case CMP:
				CMP();
				break;
			case HLT:
				HLT();
				break;
			case INT:
				INT();
				break;
			case LOOP:
				LOOP();
				break;
			default:
				break;
		}
	}

	private void LDA() {
		int address = this.ir.getData() & 0x0000ffff;	
		address = address + this.sp.getData();
		this.mar.setData(address);
		this.memory.fetch();
		this.ac.setData(this.mbr.getData());
		this.pc.setData(this.pc.getData()+1);
	}
	private void LDV() {
		int address = this.ir.getData() & 0x0000ffff;	
		this.ac.setData(address);
		this.pc.setData(this.pc.getData()+1);
	}
	private void STA() {
		int address = this.ir.getData() & 0x0000ffff;	
		address = address + this.sp.getData();
		this.mar.setData(address);
		this.mbr.setData(this.ac.getData());
		this.memory.store();
		this.pc.setData(this.pc.getData()+1);
	}
	private void ADV() {
		int address = this.ir.getData() & 0x0000ffff;	
		this.mbr.setData(address);
		this.arithmeticLogicUnit.add();
		this.pc.setData(this.pc.getData()+1);
	}
	private void ADA() {
		int address = this.ir.getData() & 0x0000ffff;	
		address = address + this.sp.getData();
		this.mar.setData(address);
		this.memory.fetch();
		this.arithmeticLogicUnit.add();
		this.pc.setData(this.pc.getData()+1);
	}
	private void HLT() {
		this.status.setStatusFlag(8);
//		this.memory.ihr(0, EInterrupt.eProcessTerminated, (this.cs.getData()/100));
//		this.pc.setData(this.pc.getData()+1);
	}
	private void INT() {
		this.status.setStatusFlag(1);
		int address = this.ir.getData() & 0x0000ffff;
		this.mar.setData(address);
		this.pc.setData(this.pc.getData()+1);
	}
	private void JGZ() {
		if(!this.status.zeroCheck() && !this.status.signCheck()) {
//			System.out.println(loopIndex + "����");
			pc.setData(loopIndex);
		}
		this.pc.setData(this.pc.getData()+1);
	}
	private void CMP() {
		int address = this.ir.getData() & 0x0000ffff;
		this.mar.setData(address + this.sp.getData());
//		this.mar.setData(address);
		this.memory.fetch();
		this.arithmeticLogicUnit.cmp();
		this.pc.setData(this.pc.getData()+1);
	}
	
	int loopIndex=0;
	private void LOOP() {
//		loopIndex = this.pc.getData() + this.cs.getData();
		loopIndex = this.pc.getData();
		this.pc.setData(this.pc.getData()+1);
	}
}

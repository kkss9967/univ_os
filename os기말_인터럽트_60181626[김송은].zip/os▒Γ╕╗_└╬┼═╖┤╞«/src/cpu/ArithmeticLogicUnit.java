package cpu;

public class ArithmeticLogicUnit {

	private Register ac, mbr;
	public void setAC(Register ac) {
		this.ac = ac;
	}
	private Status status;
	public void setStatus(Status status) {
		this.status = status;
	}

	public void connect(Register ac, Register mbr, Status status) {
		this.ac = ac;
		this.mbr = mbr;
		this.status = status;
		
		
	}

	public void cmp() {
		//maxCount count ��
		// 0���� - AC�� �ִ� �� ��. 0-> max, ac-> count. 0-ac. 
		// 0���� ������ sign�� ǥ��, 0�̸� ����

		if((this.mbr.getData() - this.ac.getData()) == 0) {
			status.setStatusFlag(4);
		}else if((this.mbr.getData() - this.ac.getData()) < 0) {
			status.setStatusFlag(2);
		}
		
		
	}

	public void add() {
		this.ac.setData(this.ac.getData() + this.mbr.getData());
	}



}

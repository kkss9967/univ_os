package cpu;

import memory.Memory;

public class CentralProcessingUnit {
	// component (��Ʈ�ѷ�)
	private ControlUnit controlUnit;
	private ArithmeticLogicUnit arithmeticLogicUnit;

	private Register pc, cs, sp, mar, mbr, ir, ac;
	private Status status;
	
	public Register getPC() {return this.controlUnit.getPc();}
	public Register getCS() {return this.controlUnit.getCs();}
	public Register getSP() {return this.controlUnit.getSp();}
	public Register getAC() {return this.controlUnit.getAc();}
	public Status getStatus() {return this.controlUnit.getStatus();}
	
	public void setPCB(Register pc, Register cs, Register sp, Register ac, Status status) {
		
		this.controlUnit.setPc(pc);
		this.controlUnit.setCs(cs);
		this.controlUnit.setSp(sp);
		this.controlUnit.setAc(ac);
		this.controlUnit.setStatus(status);
		
		this.arithmeticLogicUnit.setAC(ac);
		this.arithmeticLogicUnit.setStatus(status);
		
	}
	
	// association (��������)
	private Memory memory;

	public CentralProcessingUnit() {
		// CPU�� ���Ḹ ����
		// components
		this.controlUnit = new ControlUnit();
		this.arithmeticLogicUnit = new ArithmeticLogicUnit();

		this.pc = new Register();
		this.sp = new Register();
		this.cs = new Register();
		this.mar = new Register();
		this.mbr = new Register();
		this.ir = new Register();
		this.ac = new Register();
		this.status = new Status();

		this.controlUnit.connect(this.pc, this.mar, this.mbr, this.ir, this.sp, this.cs, this.ac, this.status);
		this.arithmeticLogicUnit.connect(this.ac, this.mbr, this.status);

		this.controlUnit.connect(this.arithmeticLogicUnit);

	}

	public void run() {
		this.controlUnit.run();


	}

	public void connect(Memory memory) {
		this.memory = memory;
		this.memory.connect(this.mar, this.mbr);
		this.controlUnit.connect(this.memory);
	}

}

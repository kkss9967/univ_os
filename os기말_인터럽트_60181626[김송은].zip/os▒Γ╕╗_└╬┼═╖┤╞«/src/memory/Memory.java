package memory;

import cpu.Register;
import processManager.InterruptHandler;
import processManager.InterruptHandler.EInterrupt;
import processManager.InterruptHandler.Interrupt;

public class Memory {
	int buffer[];
	
	
	public int[] getBuffer() {return buffer;}

	public void setBuffer(int[] buffer) {
		this.buffer = buffer;
	}
	private Register mar, mbr;
	private InterruptHandler interruptHandler;
//	private Loader loader;

	public void connect(Register mar, Register mbr) {
		this.mar = mar;
		this.mbr = mbr;
	}

	public Memory() {
		this.buffer = new int[1000];		
	}

	//�� ���� ��Ʈ�� ����
	public void fetch() {
		this.mbr.setData(this.buffer[mar.getData()]);
	}
	public void store() {
		this.buffer[this.mar.getData()] = this.mbr.getData();
	}

	public void associate(InterruptHandler interruptHandler) {
		this.interruptHandler = interruptHandler;
		
	}

	public void addInterrupt(int ac, int pid) {
		this.interruptHandler.checkInterrupt(ac, pid);
	}

	public void addHalt(int PID) {
		this.interruptHandler.checkHalt(PID);
		
	}

	
}

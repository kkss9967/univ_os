package Device;

public class IOController {
	public enum EDeviceState {
		eNone, eRunning, eFinished;
	}
	private int pid;
	private EDeviceState eDeviceState;
	private int parameter;
	private Monitor monitor;
	
	public IOController() {
		this.pid = 0;
		this.eDeviceState = EDeviceState.eNone;
		this.parameter = 0;
	}
	public void associate(Monitor monitor) {
		this.monitor = monitor;
		
	}
	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public EDeviceState geteDeviceState() {
		return eDeviceState;
	}

	public void seteDeviceState(EDeviceState eDeviceState) {
		this.eDeviceState = eDeviceState;
	}

	public int getParameter() {
		return parameter;
	}

	public void setParameter(int parameter) {
		this.parameter = parameter;
	}
	
	public void setting(int parameter, int pid) {
		this.seteDeviceState(EDeviceState.eRunning);
		this.setParameter(parameter);
		this.setPid(pid);
	}
	
	public void goWork() {
		this.monitor.setWork(pid, parameter);
		this.monitor.work();
		this.eDeviceState = EDeviceState.eFinished;
	}
	
}

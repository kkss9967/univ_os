package Device;

public class Monitor {

	private int parameter;
	private int pid;
	
	public void setWork(int pid, int parameter) {
		this.pid = pid;
		this.parameter = parameter;
	}

	public void work() {
		System.out.println();
		System.out.println("Monitor----------------------");
		System.out.println("���μ��� " + pid + '\n' + "---------> sum: " +this.parameter);
		System.out.println("-----------------------------");
		System.out.println();
	
	}

}
